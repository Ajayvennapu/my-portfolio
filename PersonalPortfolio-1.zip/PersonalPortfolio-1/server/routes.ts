import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema } from "../shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for submitting contact form
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      // Validate request body using the zod schema
      const validatedData = insertContactMessageSchema.parse(req.body);
      
      // Store the contact message in the database
      const result = await storage.createContactMessage(validatedData);
      
      // Return success response
      res.status(201).json({
        success: true,
        message: "Your message has been sent successfully!",
        data: result
      });
    } catch (error) {
      console.error("Error processing contact form submission:", error);
      
      // Handle validation errors
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid form data",
          errors: error.errors
        });
      }
      
      // Handle other errors
      res.status(500).json({ 
        success: false,
        message: "An error occurred while processing your message" 
      });
    }
  });

  // API route for getting all contact messages (admin only in a real app)
  app.get("/api/contact/messages", async (_req: Request, res: Response) => {
    try {
      const messages = await storage.getAllContactMessages();
      res.status(200).json({ 
        success: true,
        data: messages 
      });
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ 
        success: false,
        message: "An error occurred while fetching messages" 
      });
    }
  });

  // API route for marking a message as read (admin only in a real app)
  app.patch("/api/contact/messages/:id/read", async (req: Request, res: Response) => {
    try {
      const messageId = parseInt(req.params.id);
      
      if (isNaN(messageId)) {
        return res.status(400).json({ 
          success: false,
          message: "Invalid message ID" 
        });
      }
      
      const success = await storage.markMessageAsRead(messageId);
      
      if (!success) {
        return res.status(404).json({ 
          success: false,
          message: "Message not found" 
        });
      }
      
      res.status(200).json({ 
        success: true,
        message: "Message marked as read" 
      });
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ 
        success: false,
        message: "An error occurred while updating the message" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
