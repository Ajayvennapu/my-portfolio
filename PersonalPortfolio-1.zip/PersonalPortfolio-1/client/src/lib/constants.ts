export const SKILLS = [
  { name: "Python", level: 90 },
  { name: "HTML/CSS", level: 85 },
  { name: "JavaScript", level: 80 },
  { name: "Machine Learning", level: 85 },
  { name: "AI/NLP", level: 80 },
  { name: "SQL", level: 75 },
  { name: "UI/UX Design", level: 80 },
  { name: "Problem Solving", level: 85 }
];

export const PROJECTS = [
  {
    title: "Personal Portfolio Website",
    description: "Designed and developed a modern portfolio website with advanced animations, 3D effects, and responsive design to showcase projects and skills. Features include particle backgrounds, interactive UI elements, and database integration.",
    image: "/images/portfolio-project.jpg",
    featured: true,
    tags: ["React", "TailwindCSS", "Framer Motion", "PostgreSQL"],
    link: "#",
    repoLink: "https://github.com/Ajayvennapu"
  },
  {
    title: "Life Insurance Prediction",
    description: "Built a web application to predict insurance acceptance using Random Forest & Decision Tree algorithms, enhancing decision-making accuracy.",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40",
    tags: ["Python", "ML", "Web App"],
    link: "#"
  },
  {
    title: "Tourism Website",
    description: "Designed and developed a responsive tourism website that improved user experience and reduced load times by 20%.",
    image: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800",
    tags: ["HTML", "CSS", "JavaScript"],
    link: "#"
  },
  {
    title: "WhatsApp Clone UI",
    description: "Created a modern WhatsApp-like chat interface with interactive elements and real-time chat bubbles. Implemented responsive design and animated transitions.",
    image: "/images/whatsapp-project.jpg",
    tags: ["HTML", "CSS", "UI/UX", "JavaScript"],
    link: "#",
    customBg: "bg-gradient-to-br from-emerald-500/10 to-emerald-700/10"
  }
];

export const CERTIFICATIONS = [
  {
    title: "Python Programming",
    issuer: "Edyst",
    date: "2023",
    link: "#"
  },
  {
    title: "HTML & CSS",
    issuer: "SoloLearn",
    date: "2023",
    link: "#"
  },
  {
    title: "Salesforce Development",
    issuer: "AICTE",
    date: "2023",
    link: "#"
  },
  {
    title: "AI & ML Fundamentals",
    issuer: "Coursera",
    date: "2024",
    link: "#"
  },
  {
    title: "Ethical Hacking & Cybersecurity",
    issuer: "Eduskills",
    date: "2024",
    link: "#"
  }
];

export const EXPERIENCE = [
  {
    title: "Frontend Intern",
    company: "IIT Hyderabad",
    period: "May 2022 - Aug 2022",
    description: "Built a Color Polling Web App using JavaScript, boosting user engagement by 40%."
  },
  {
    title: "Salesforce Developer Intern",
    company: "AICTE",
    period: "Aug 2023 - Nov 2023",
    description: "Optimized UI for Salesforce apps, improving workflow efficiency by 15%."
  },
  {
    title: "Web Developer Intern",
    company: "Eduskills Platform",
    period: "Sep 2024 - Dec 2024",
    description: "Worked on Salesforce Development in a sub-internship role, streamlining UI processes and enhancing internal app performance."
  }
];