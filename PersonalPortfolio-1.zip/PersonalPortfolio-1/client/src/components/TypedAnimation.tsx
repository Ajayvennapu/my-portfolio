import { useEffect, useRef } from 'react';
import Typed from 'typed.js';

interface TypedAnimationProps {
  strings: string[];
  className?: string;
}

export default function TypedAnimation({ strings, className = '' }: TypedAnimationProps) {
  const el = useRef<HTMLSpanElement>(null);
  const typed = useRef<Typed | null>(null);

  useEffect(() => {
    if (el.current) {
      typed.current = new Typed(el.current, {
        strings,
        typeSpeed: 50,
        backSpeed: 30,
        loop: true,
        backDelay: 1500,
        startDelay: 300,
        cursorChar: '|',
        smartBackspace: true,
      });
    }

    return () => {
      if (typed.current) {
        typed.current.destroy();
      }
    };
  }, [strings]);

  return <span ref={el} className={className}></span>;
}