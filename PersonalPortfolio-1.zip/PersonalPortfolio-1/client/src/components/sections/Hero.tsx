import { motion } from "framer-motion";
import AnimatedText from "../shared/AnimatedText";
import { Button } from "@/components/ui/button";
import { Download, ChevronDown, Github, Linkedin } from "lucide-react";
import { float } from "@/lib/animations";
import ParticlesBackground from "../ParticlesBackground";
import TypedAnimation from "../TypedAnimation";

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center relative overflow-hidden py-20 lg:py-0" style={{ 
      background: 'black',
      backgroundImage: 'radial-gradient(circle at 10% 20%, rgba(0, 255, 255, 0.05) 0%, rgba(255, 0, 255, 0.05) 90%)'
    }}>
      {/* Advanced particles background */}
      <ParticlesBackground />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-4 font-serif">
              <AnimatedText 
                text="AJAY VENNAPU" 
                className="!justify-center lg:!justify-start gradient-text neon-text" 
              />
            </h1>

            <div className="text-lg sm:text-xl lg:text-2xl text-white mb-6 flex justify-center lg:justify-start">
              <TypedAnimation 
                strings={[
                  "Aspiring Software Developer",
                  "AI Specialist",
                  "Frontend Developer",
                  "Problem Solver",
                  "Innovator"
                ]}
                className="typed-animation text-cyan-400 font-medium"
              />
            </div>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="text-gray-300 mb-8 text-base sm:text-lg max-w-2xl mx-auto lg:mx-0"
            >
              Aspiring Software Developer with a passion for building innovative and high-performance applications that contribute to the growth of an organization. Committed to problem-solving, continuous learning, and leveraging technology to create impactful software solutions.
            </motion.p>

            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-cyan-500 via-purple-500 to-fuchsia-500 hover:opacity-90 transition-all transform hover:scale-105 hover-glow"
                asChild
              >
                <a href="#projects">View Projects</a>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-gray-500 hover:border-cyan-400 transition-all transform hover:scale-105 hover-glow"
                asChild
              >
                <a href="/resume.pdf" download>
                  <Download className="mr-2 h-4 w-4" />
                  Download CV
                </a>
              </Button>
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-purple-500 to-cyan-500 hover:opacity-90 transition-all transform hover:scale-105 hover-glow"
                asChild
              >
                <a href="#contact">
                  Hire Me
                </a>
              </Button>
            </motion.div>

            <motion.div 
              className="flex justify-center lg:justify-start space-x-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <a 
                href="https://github.com/Ajayvennapu" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-cyan-500 transition-colors transform hover:scale-110 hover-glow"
              >
                <Github className="h-6 w-6" />
              </a>
              <a 
                href="https://linkedin.com/in/ajay-vennapu" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-cyan-500 transition-colors transform hover:scale-110 hover-glow"
              >
                <Linkedin className="h-6 w-6" />
              </a>
            </motion.div>
          </motion.div>

          <motion.div
            variants={float}
            initial="initial"
            animate="animate"
            className="relative max-w-md mx-auto max-w-none block"
          >
            {/* Profile image container with enhanced animation and glow effects */}
            <motion.div
              whileHover={{ scale: 1.02, rotate: [0, -1, 1, -1, 0] }}
              transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
              className="relative w-64 h-64 sm:w-80 sm:h-80 mx-auto"
            >
              <div className="w-full h-full rounded-full overflow-hidden relative profile-glow" style={{ padding: "2px" }}>
                <img
                  src="/images/profile.jpg"
                  alt="Ajay Vennapu"
                  className="profile-image"
                  style={{
                    objectFit: "cover",
                    objectPosition: "center 25%",
                    transform: "scale(0.92)",
                    marginTop: "-20px"
                  }}
                />
                
                {/* Floating particles around the profile */}
                <div className="absolute top-0 left-0 w-full h-full">
                  {[...Array(8)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-2 h-2 rounded-full bg-cyan-500"
                      style={{
                        top: `${Math.random() * 100}%`,
                        left: `${Math.random() * 100}%`,
                      }}
                      animate={{
                        x: [0, Math.random() * 20 - 10],
                        y: [0, Math.random() * 20 - 10],
                        opacity: [0.7, 0.2, 0.7],
                        scale: [1, 1.5, 1],
                      }}
                      transition={{
                        duration: 3 + Math.random() * 2,
                        repeat: Infinity,
                        repeatType: "reverse",
                      }}
                    />
                  ))}
                </div>
              </div>
              
              {/* Pulsing ring outside the profile image */}
              <motion.div
                className="absolute -inset-4 rounded-full border-2 border-cyan-500/30"
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.3, 0.1, 0.3],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  repeatType: "reverse",
                }}
              />
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ 
            duration: 0.8,
            repeat: Infinity,
            repeatType: "reverse"
          }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer hidden lg:block"
        >
          <ChevronDown className="w-8 h-8 text-white animate-bounce" />
        </motion.div>
      </div>
    </section>
  );
}