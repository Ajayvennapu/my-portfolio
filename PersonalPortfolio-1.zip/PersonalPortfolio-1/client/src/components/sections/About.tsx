import { motion } from "framer-motion";
import AnimatedText from "../shared/AnimatedText";
import { Card, CardContent } from "@/components/ui/card";
import { fadeIn, staggerContainer } from "@/lib/animations";

export default function About() {
  return (
    <section id="about" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <AnimatedText
            text="About Me"
            className="text-3xl md:text-4xl font-bold mb-4 justify-center"
          />
          <AnimatedText
            text="My Introduction"
            className="text-primary text-lg md:text-xl mb-8 justify-center"
          />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div variants={fadeIn("right")} className="col-span-2">
            <Card className="overflow-hidden group hover:border-cyan-500/50 transition-all duration-300">
              <CardContent className="p-6 relative background-card">
                <h3 className="text-xl font-semibold mb-4 text-gradient bg-gradient-to-r from-cyan-400 to-fuchsia-500">Background</h3>
                <div className="relative z-10">
                  <p className="text-foreground/90 mb-4 leading-relaxed text-">
                    B.Tech CSE student specializing in AI with a passion for web development
                    and cybersecurity. Throughout my academic journey, I've cultivated 
                    expertise in both frontend and backend technologies, while also 
                    exploring ethical hacking and AI integration.
                  </p>
                  <p className="text-foreground/90 mb-4">
                    My internship experiences at AICTE as a Salesforce Developer and at 
                    Eduskills in Ethical Hacking have enhanced my practical skills and
                    problem-solving abilities in real-world scenarios.
                  </p>
                  <p className="text-foreground/90">
                    I'm particularly interested in creating innovative applications
                    that incorporate AI capabilities to solve complex problems. My goal is 
                    to join a forward-thinking team where I can apply my diverse skill set 
                    while continuing to grow as a technology professional.
                  </p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-fuchsia-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeIn("left")}>
            <Card className="overflow-hidden group hover:border-cyan-500/50 transition-all duration-300">
              <CardContent className="p-6 relative education-card">
                <h3 className="text-xl font-semibold mb-4 text-gradient bg-gradient-to-r from-cyan-400 to-fuchsia-500">Education</h3>
                <div className="space-y-6 relative z-10">
                  <motion.div 
                    className="p-4 rounded-lg backdrop-blur-sm bg-gradient-to-r from-background/40 to-background/60 border border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 255, 255, 0.1)" }}
                  >
                    <h4 className="font-medium text-cyan-400">B.Tech in Computer Science and Engineering (AI Specialization)</h4>
                    <p className="text-foreground/80">KIET Engineering College, Andhra Pradesh</p>
                    <p className="text-sm text-foreground/60">2022 - 2025</p>
                    <p className="text-sm text-foreground/80 mt-1">CGPA: 7.71 | Percentage: 70%</p>
                  </motion.div>
                  
                  <motion.div 
                    className="p-4 rounded-lg backdrop-blur-sm bg-gradient-to-r from-background/40 to-background/60 border border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 255, 255, 0.1)" }}
                  >
                    <h4 className="font-medium text-fuchsia-400">Diploma in Electronics and Communication Engineering</h4>
                    <p className="text-foreground/80">Aditya Engineering College, Andhra Pradesh</p>
                    <p className="text-sm text-foreground/60">2018 - 2022</p>
                    <p className="text-sm text-foreground/80 mt-1">Percentage: 68%</p>
                  </motion.div>
                  
                  <motion.div 
                    className="p-4 rounded-lg backdrop-blur-sm bg-gradient-to-r from-background/40 to-background/60 border border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300"
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 255, 255, 0.1)" }}
                  >
                    <h4 className="font-medium text-cyan-400">SSC (Secondary School Certificate)</h4>
                    <p className="text-foreground/80">ZP High School, Unduru, Andhra Pradesh</p>
                    <p className="text-sm text-foreground/60">2018</p>
                    <p className="text-sm text-foreground/80 mt-1">GPA: 9.2</p>
                  </motion.div>
                </div>
                <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-fuchsia-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
