import { motion } from "framer-motion";
import AnimatedText from "../shared/AnimatedText";
import { Progress } from "@/components/ui/progress";
import { SKILLS } from "@/lib/constants";
import { fadeIn, staggerContainer } from "@/lib/animations";

export default function Skills() {
  return (
    <section id="skills" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <AnimatedText
            text="Skills"
            className="text-3xl md:text-4xl font-bold mb-4 justify-center"
          />
          <AnimatedText
            text="My Technical Level"
            className="text-primary text-lg md:text-xl mb-8 justify-center"
          />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {SKILLS.map((skill, index) => (
            <motion.div
              key={skill.name}
              variants={fadeIn(index % 2 === 0 ? "right" : "left")}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="space-y-2"
            >
              <div className="flex justify-between items-center">
                <h3 className="font-medium">{skill.name}</h3>
                <span className="text-sm text-foreground/60">{skill.level}%</span>
              </div>
              <Progress value={skill.level} className="h-2" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
