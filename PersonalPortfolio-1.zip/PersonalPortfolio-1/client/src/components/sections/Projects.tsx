import { useState, useRef, useEffect } from "react";
import { motion, useAnimation, useMotionValue, useTransform, AnimatePresence } from "framer-motion";
import AnimatedText from "../shared/AnimatedText";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PROJECTS } from "@/lib/constants";
import { staggerContainer, scaleIn, fadeIn } from "@/lib/animations";
import { ExternalLink, Code, Eye, Github, Star } from "lucide-react";

// Define Project type
interface Project {
  title: string;
  description: string;
  image: string;
  tags: string[];
  link: string;
  featured?: boolean;
  repoLink?: string;
  customBg?: string;
}

const categories = Array.from(
  new Set(PROJECTS.flatMap((project) => project.tags))
);

// Card tilt effect component
const TiltCard = ({ children }: { children: React.ReactNode }) => {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const rotateX = useTransform(y, [-100, 100], [30, -30]);
  const rotateY = useTransform(x, [-100, 100], [-30, 30]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const moveX = (e.clientX - centerX) / 5;
    const moveY = (e.clientY - centerY) / 5;
    
    x.set(moveX);
    y.set(moveY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="w-full h-full"
    >
      <div style={{ transform: "translateZ(20px)" }} className="w-full h-full">
        {children}
      </div>
    </motion.div>
  );
};

export default function Projects() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const controls = useAnimation();

  useEffect(() => {
    controls.start((i) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.1 }
    }));
  }, [selectedCategory, controls]);

  const filteredProjects = selectedCategory
    ? PROJECTS.filter((project) => project.tags.includes(selectedCategory))
    : PROJECTS;

  return (
    <section id="projects" className="py-20 relative overflow-hidden">
      {/* Background layers for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background/90"></div>
      
      {/* Glowing orbs in background */}
      <motion.div 
        className="absolute w-40 h-40 rounded-full bg-cyan-500/10 blur-3xl -top-10 -left-10"
        animate={{ 
          x: [0, 30, 0], 
          y: [0, 20, 0],
          opacity: [0.2, 0.3, 0.2] 
        }} 
        transition={{ repeat: Infinity, duration: 15, ease: "easeInOut" }}
      />
      
      <motion.div 
        className="absolute w-60 h-60 rounded-full bg-fuchsia-500/10 blur-3xl -bottom-20 -right-20"
        animate={{ 
          x: [0, -20, 0], 
          y: [0, -30, 0],
          opacity: [0.2, 0.4, 0.2] 
        }} 
        transition={{ repeat: Infinity, duration: 18, ease: "easeInOut" }}
      />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-3">
              <span className="text-gradient bg-gradient-to-r from-cyan-400 to-fuchsia-500">Projects</span>
            </h2>
          </motion.div>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-foreground/70 mb-8"
          >
            Showcasing my latest creations and innovations
          </motion.p>
        </motion.div>

        <motion.div 
          className="flex flex-wrap justify-center gap-3 mb-10 px-2"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Button
            size="sm"
            variant={selectedCategory === null ? "default" : "outline"}
            onClick={() => setSelectedCategory(null)}
            className="mb-2 relative overflow-hidden group"
          >
            <span className="relative z-10">All</span>
            {selectedCategory === null && (
              <motion.span 
                className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-fuchsia-500"
                layoutId="categoryBackground"
                transition={{ type: "spring", duration: 0.5 }}
              />
            )}
          </Button>
          
          {categories.map((category) => (
            <Button
              key={category}
              size="sm"
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className="mb-2 relative overflow-hidden group"
            >
              <span className="relative z-10">{category}</span>
              {selectedCategory === category && (
                <motion.span 
                  className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-fuchsia-500"
                  layoutId="categoryBackground"
                  transition={{ type: "spring", duration: 0.5 }}
                />
              )}
            </Button>
          ))}
        </motion.div>

        {/* Featured Projects Row - only show if there's at least one featured project and no category filter */}
        <AnimatePresence>
          {selectedCategory === null && filteredProjects.some(p => p.featured) && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-12"
            >
              <div className="flex items-center gap-2 mb-6">
                <Star className="text-yellow-500 h-5 w-5" />
                <h3 className="text-xl font-medium text-gradient bg-gradient-to-r from-yellow-400 to-amber-500">Featured Project</h3>
              </div>
              
              {/* Display featured project in a larger card */}
              {filteredProjects
                .filter(project => project.featured)
                .map((project, index) => (
                  <motion.div
                    key={project.title}
                    custom={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="perspective-container"
                  >
                    <Card className="overflow-hidden glass-card border border-yellow-500/30 backdrop-blur-sm bg-background/30 group transition-all duration-300 hover:-translate-y-2">
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
                        {/* Project image */}
                        <div className="relative overflow-hidden">
                          {/* Glowing border that appears on hover */}
                          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <div className="absolute inset-0 border-2 border-yellow-500/50 z-10"></div>
                          </div>
                          
                          <img
                            src={project.image}
                            alt={project.title}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 min-h-[300px] object-center"
                          />
                          
                          {/* Hover overlay with featured tag */}
                          <div className="absolute top-0 left-0 bg-gradient-to-r from-yellow-500 to-amber-500 text-white py-1 px-3 rounded-br-md font-medium text-sm flex items-center gap-1">
                            <Star className="h-3 w-3" fill="white" /> Featured
                          </div>
                        </div>
                        
                        <CardContent className="p-8 relative z-10 flex flex-col">
                          {/* Project title with gradient effect */}
                          <h3 className="text-2xl font-bold mb-3 text-gradient bg-gradient-to-r from-yellow-400 to-amber-500">{project.title}</h3>
                          
                          {/* Project description */}
                          <p className="text-foreground/90 mb-6">{project.description}</p>
                          
                          {/* Tags with glow effect */}
                          <div className="flex flex-wrap gap-2 mb-6">
                            {project.tags.map((tag) => (
                              <Badge 
                                key={tag} 
                                variant="secondary" 
                                className="text-sm bg-gradient-to-r from-yellow-500/10 to-amber-500/10 border border-yellow-500/20 hover:border-yellow-500/50 transition-colors"
                              >
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          
                          {/* Action buttons */}
                          <div className="mt-auto flex flex-col sm:flex-row gap-3">
                            <Button 
                              asChild 
                              className="bg-gradient-to-r from-yellow-500 to-amber-500 hover:shadow-[0_0_15px_rgba(234,179,8,0.5)] transition-all transform hover:scale-102 hover:translate-y-[-2px]"
                            >
                              <a href={project.link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center">
                                Demo <ExternalLink className="ml-2 h-4 w-4" />
                              </a>
                            </Button>
                            
                            {project.repoLink && (
                              <Button 
                                asChild 
                                variant="outline"
                                className="border-yellow-500/30 hover:border-yellow-500/60 hover:bg-yellow-500/10 transition-all"
                              >
                                <a href={project.repoLink} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center">
                                  <Github className="mr-2 h-4 w-4" /> GitHub Repo
                                </a>
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </div>
                    </Card>
                  </motion.div>
                ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Regular Projects Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects
            .filter(project => !project.featured || selectedCategory !== null)
            .map((project, index) => (
              <motion.div
                key={project.title}
                custom={index}
                initial={{ opacity: 0, y: 50 }}
                animate={controls}
                exit={{ opacity: 0, y: -50 }}
                className="h-full perspective-container"
              >
                <TiltCard>
                  <Card className={`overflow-hidden h-full glass-card border border-cyan-500/20 backdrop-blur-sm ${project.customBg || 'bg-background/30'} group transform transition-all duration-300 hover:-translate-y-2`}>
                    <div className="aspect-video relative overflow-hidden">
                      {/* Overlay with hover effect */}
                      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-fuchsia-500/20 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                      
                      {/* Glowing border that appears on hover */}
                      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="absolute inset-0 border-2 border-cyan-500/50 z-10 rounded-t-md"></div>
                      </div>
                      
                      {/* Project image */}
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      
                      {/* Hover overlay with buttons */}
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 z-20">
                        <div className="flex gap-3">
                          <motion.div whileHover={{ y: -5 }} whileTap={{ y: 0 }}>
                            <Button size="sm" variant="secondary" className="rounded-full hover-glow flex items-center justify-center w-10 h-10 p-0" asChild>
                              <a href={project.link} target="_blank" rel="noopener noreferrer">
                                <Eye className="h-4 w-4" />
                              </a>
                            </Button>
                          </motion.div>
                          {project.repoLink && (
                            <motion.div whileHover={{ y: -5 }} whileTap={{ y: 0 }}>
                              <Button size="sm" variant="secondary" className="rounded-full hover-glow flex items-center justify-center w-10 h-10 p-0" asChild>
                                <a href={project.repoLink} target="_blank" rel="noopener noreferrer">
                                  <Github className="h-4 w-4" />
                                </a>
                              </Button>
                            </motion.div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <CardContent className="p-6 glass-card-content relative z-10">
                      {/* Project title with gradient effect on hover */}
                      <h3 className="text-xl font-semibold mb-2 group-hover:text-gradient group-hover:bg-gradient-to-r group-hover:from-cyan-400 group-hover:to-fuchsia-500 transition-all duration-300">{project.title}</h3>
                      
                      {/* Project description */}
                      <p className="text-foreground/80 mb-4 line-clamp-2">{project.description}</p>
                      
                      {/* Tags with neon glow effect */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.tags.map((tag) => (
                          <Badge 
                            key={tag} 
                            variant="secondary" 
                            className="text-sm bg-gradient-to-r from-cyan-500/10 to-fuchsia-500/10 border border-cyan-500/20 hover:border-cyan-500/50 transition-colors"
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      {/* Project link button with gradient and glow */}
                      <Button 
                        asChild 
                        className="w-full bg-gradient-to-r from-cyan-500 via-purple-500 to-fuchsia-500 hover:shadow-[0_0_15px_rgba(0,255,255,0.5)] transition-all transform hover:scale-102 hover:translate-y-[-2px]"
                      >
                        <a href={project.link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center">
                          View Project <ExternalLink className="ml-2 h-4 w-4" />
                        </a>
                      </Button>
                    </CardContent>
                  </Card>
                </TiltCard>
              </motion.div>
            ))}
        </div>
      </div>
    </section>
  );
}