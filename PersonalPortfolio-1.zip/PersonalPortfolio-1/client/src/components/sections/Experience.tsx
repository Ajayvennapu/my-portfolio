
import { motion } from "framer-motion";
import AnimatedText from "../shared/AnimatedText";
import { EXPERIENCE } from "@/lib/constants";
import { Briefcase, Building2 } from "lucide-react";
import { fadeIn, staggerContainer } from "@/lib/animations";

export default function Experience() {
  return (
    <section id="experience" className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <AnimatedText
            text="Experience"
            className="text-3xl md:text-4xl font-bold mb-4 justify-center"
          />
          <AnimatedText
            text="My Professional Journey"
            className="text-primary text-lg md:text-xl mb-8 justify-center"
          />
        </motion.div>

        <div className="grid gap-8 max-w-4xl mx-auto">
          {EXPERIENCE.map((exp, index) => (
            <motion.div
              key={exp.company}
              variants={fadeIn("up")}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              custom={index}
            >
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="p-6 rounded-lg border border-cyan-500/20 bg-gradient-to-r from-background/95 to-background/90 backdrop-blur-sm relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-fuchsia-500/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg" />
                
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-full bg-cyan-500/10 border border-cyan-500/20 group-hover:border-cyan-500/40 transition-colors">
                    <Briefcase className="w-6 h-6 text-cyan-400" />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-1 text-gradient bg-gradient-to-r from-cyan-400 to-fuchsia-500">
                      {exp.title}
                    </h3>
                    <div className="flex items-center gap-2 mb-3 text-foreground/70">
                      <Building2 className="w-4 h-4" />
                      <span>{exp.company}</span>
                      <span className="text-foreground/50">•</span>
                      <span className="text-sm">{exp.period}</span>
                    </div>
                    <p className="text-foreground/80">{exp.description}</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
