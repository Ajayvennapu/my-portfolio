import { motion } from "framer-motion";
import { Github, Linkedin, Mail, Heart } from "lucide-react";

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      className="bg-gradient-to-r from-background/90 to-background py-8 border-t border-cyan-500/10"
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <motion.p 
            className="text-foreground/80 flex items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            © {new Date().getFullYear()} Built with <Heart className="h-4 w-4 mx-1 text-fuchsia-500 animate-pulse" /> by <span className="text-cyan-400 ml-1">Ajay Vennapu</span>
          </motion.p>
          
          <motion.div 
            className="flex space-x-6 mt-4 md:mt-0"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <a
              href="https://github.com/Ajayvennapu"
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground/80 hover:text-cyan-400 transition-colors transform hover:scale-125 duration-300"
            >
              <Github className="h-5 w-5" />
            </a>
            <a
              href="https://linkedin.com/in/ajay-vennapu"
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground/80 hover:text-cyan-400 transition-colors transform hover:scale-125 duration-300"
            >
              <Linkedin className="h-5 w-5" />
            </a>
            <a
              href="mailto:ajayvennapu4@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground/80 hover:text-cyan-400 transition-colors transform hover:scale-125 duration-300"
            >
              <Mail className="h-5 w-5" />
            </a>
          </motion.div>
        </div>
      </div>
    </motion.footer>
  );
}
