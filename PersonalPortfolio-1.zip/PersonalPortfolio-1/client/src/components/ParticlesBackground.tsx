import { useEffect } from 'react';
import { particlesConfig } from '../lib/particlesConfig';

declare global {
  interface Window {
    particlesJS: any;
  }
}

export default function ParticlesBackground() {
  useEffect(() => {
    // Load particles.js
    if (window.particlesJS) {
      window.particlesJS('particles-js', particlesConfig);
    } else {
      // If window.particlesJS is not available, load the script
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js';
      script.async = true;
      script.onload = () => {
        window.particlesJS('particles-js', particlesConfig);
      };
      document.body.appendChild(script);
    }

    // Cleanup
    return () => {
      const script = document.querySelector('script[src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"]');
      if (script) {
        document.body.removeChild(script);
      }
    };
  }, []);

  return (
    <div 
      id="particles-js" 
      className="absolute inset-0 z-0"
      style={{ pointerEvents: 'none' }}
    ></div>
  );
}